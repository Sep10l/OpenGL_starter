#pragma once
const char* logl_root = "C:/Users/mihne/source/repos/OpenGL";